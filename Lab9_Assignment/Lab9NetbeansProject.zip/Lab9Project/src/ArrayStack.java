import java.util.EmptyStackException;
//implement your ArrayStack implementation here


public class ArrayStack implements DStack
{
     public ArrayStack()
     {
             // Your constructor code 
     }
     @Override
    public boolean isEmpty() 
    {
            // Insert your isEmpty code here
          return false;  //Replace with your own return statement
    }
    @Override
    public void push(double d) 
    {
         // Insert your push code here
    }
    @Override
    public double pop()
    {
         // Insert your pop code here
        return 0;  //replace with your own return statement
    }
    @Override
    public double peek()
    {
        // Insert your peek code here
         return 0;  //replace with your own return statement
    }
}
