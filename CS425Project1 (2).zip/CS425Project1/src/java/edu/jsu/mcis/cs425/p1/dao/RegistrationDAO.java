/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;

/**
 *
 * @author makiy
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.github.cliftonlabs.json_simple.*;

public class RegistrationDAO {

    private static final String QUERY = "SELECT id FROM student WHERE username = ?";
    private static final String QUERY_CREATE = "INSERT INTO registration (studentid, termid, crn) VALUES (?, ?, ?)";
    private static final String QUERY_LIST = "SELECT * FROM ((registration JOIN section ON registration.crn = section.crn) JOIN `subject` ON `subject`.id = section.subjectid) WHERE studentid = ? AND registration.termid = ?";
    private static final String QUERY_DELETE = "DELETE FROM registration WHERE studentid = ? AND termid = ? AND crn = ?";

    private final DAOFactory daoFactory;

    public RegistrationDAO(DAOFactory daoFactory) {
        this.daoFactory = daoFactory;
    }

    public int getStudentId(String username) {
        
        
        try {
            
                Connection conn = daoFactory.getConnection();
                
                PreparedStatement ps = conn.prepareStatement(QUERY);
            
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("id");
                }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }   
        return -1;
    }

    public void registerCourse(int studentId, String termId, String crn) {

        
        try {
            
        
            Connection conn = daoFactory.getConnection();
                
            PreparedStatement ps = conn.prepareStatement(QUERY_CREATE);
            
            ps.setInt(1, studentId);
            ps.setString(2, termId);
            ps.setString(3, crn);
            ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public JsonArray listRegistrations(int studentId, String termId) {
        
        JsonArray jsonRegistrations = new JsonArray();

        try {
            
            Connection conn = daoFactory.getConnection();
                
            PreparedStatement ps = conn.prepareStatement(QUERY_LIST);
            
            ps.setInt(1, studentId);
            ps.setString(2, termId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                JsonObject json = new JsonObject();
                int columnCount = rs.getMetaData().getColumnCount();
                for (int i = 1; i <= columnCount; i++) {
                String columnName = rs.getMetaData().getColumnName(i);
                Object value = rs.getObject(i);
                if (value != null) {
                        json.put(columnName, value.toString());
                    } else {
                        json.put(columnName, null);
                    }
            }
            jsonRegistrations.add(json);
        }
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jsonRegistrations;
    }
    
    public void deleteRegistration(int studentId, String termId, String crn) {
        
        
        try (Connection conn = daoFactory.getConnection();
                
            PreparedStatement ps = conn.prepareStatement(QUERY_DELETE)) {
            
            ps.setInt(1, studentId);
            ps.setString(2, termId);
            ps.setString(3, crn);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    

