/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;

/**
 *
 * @author makiy
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import com.github.cliftonlabs.json_simple.*;
import java.time.LocalDate;
import java.util.Map;

public class SearchDAO {
    
    private static final String QUERY_FIND = "SELECT course.*, section.*, "
    + "term.name AS termname, term.`start` AS termstart, term.`end` AS termend, "
    + "scheduletype.description as scheduletype, `level`.description as `level` "
    + "FROM ((((section JOIN scheduletype ON section.scheduletypeid = scheduletype.id) "
    + "JOIN course ON section.subjectid = course.subjectid AND section.num = course.num) "
    + "JOIN `level` ON course.levelid = `level`.id) "
    + "JOIN term ON section.termid = term.id) "

    + "WHERE ((? IS NULL OR course.subjectid = ?) "    // subjectid (parameters 1 & 2)
    + "AND (? IS NULL OR course.num = ?) "             // num (parameters 3 & 4)
    + "AND (? IS NULL OR `level`.id = ?) "             // levelid (parameters 5 & 6)
    + "AND (? IS NULL OR section.scheduletypeid = ?) " // scheduletypeid (parameters 7 & 8)
    + "AND (? IS NULL OR section.`start` >= ?) "       // start as LocalTime (parameters 9 & 10)
    + "AND (? IS NULL OR section.`end` <= ?) "         // end as LocalTime (parameters 11 & 12)
    + "AND (? IS NULL OR section.days REGEXP ?) "      // days (ex: "M|W|F") (parameters 13 & 14)
    + "AND (section.termid = ?)) "                     // termid (parameter 15)
    + "ORDER BY course.num, section";
    
    private final DAOFactory daoFactory;

    public SearchDAO(DAOFactory daoFactory) {
        this.daoFactory = daoFactory;
    }

    public JsonArray search(Map<String, String[]> params, String termid) {

        JsonArray jsonSearch = new JsonArray();

        try {
            
            Connection conn = daoFactory.getConnection();
            PreparedStatement ps = conn.prepareStatement(QUERY_FIND);
            
            
            ps.setString(1, params.containsKey("subjectid") && !params.get("subjectid")[0].equals("") ? params.get("subjectid")[0] : null);
            ps.setString(2, params.containsKey("subjectid") && !params.get("subjectid")[0].equals("")? params.get("subjectid")[0] : null);
            ps.setString(3, params.containsKey("num") && !params.get("num")[0].equals("") ? params.get("num")[0] : null);
            ps.setString(4, params.containsKey("num") && !params.get("num")[0].equals("") ? params.get("num")[0] : null);
            ps.setString(5, params.containsKey("levelid") && !params.get("levelid")[0].equals("") ? params.get("levelid")[0] : null);
            ps.setString(6, params.containsKey("levelid") && !params.get("levelid")[0].equals("") ? params.get("levelid")[0] : null);
            ps.setString(7, params.containsKey("scheduletypeid") && !params.get("scheduletypeid")[0].equals("") ? params.get("scheduletypeid")[0] : null);
            ps.setString(8, params.containsKey("scheduletypeid") && !params.get("scheduletypeid")[0].equals("") ? params.get("scheduletypeid")[0] : null);
            ps.setString(9, params.containsKey("start") && !params.get("start")[0].equals("") ? params.get("start")[0] : null);
            ps.setString(10, params.containsKey("start") && !params.get("start")[0].equals("") ? params.get("start")[0] : null);
            ps.setString(11, params.containsKey("end") && !params.get("end")[0].equals("") ? params.get("end")[0] : null);
            ps.setString(12, params.containsKey("end") && !params.get("end")[0].equals("") ? params.get("end")[0] : null);
            ps.setString(13, params.containsKey("days") && !params.get("days")[0].equals("") ? params.get("days")[0] : null);
            ps.setString(14, params.containsKey("days") && !params.get("days")[0].equals("") ? params.get("days")[0] : null);
            ps.setString(15, params.containsKey("termid") && !params.get("termid")[0].equals("") ? params.get("termid")[0] : null);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                
                JsonObject json = new JsonObject();

                int columnCount = rs.getMetaData().getColumnCount();
                
                for (int i = 1; i <= columnCount; i++) {
                    
                    String columnName = rs.getMetaData().getColumnName(i);
                    Object value = rs.getString(i); 

                  
                    if (value != null) {
                        json.put(columnName, value);
                    } else {
                        json.put(columnName, null);
                    }
                }

                jsonSearch.add(json); 
        
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonSearch;
    }
}

