package edu.jsu.mcis.cs350;

public class Lab3Model extends AbstractModel {
    
    private final BoundedBuffer buffer;
    
    public Lab3Model() {
 
        buffer = new BoundedBuffer(this);
    }

    public void setAddElement(String value) {
        
        StringBuilder s = new StringBuilder();
        
        // INSERT YOUR CODE HERE
        String[] letters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        
        for (int i = 0; i < 26; i++) {
            if (value.equals(letters[i])) {
                buffer.insert(value);
                s.append("Page Added: ").append(value).append(System.lineSeparator());
            }
        }
        
        s.append(buffer);

        firePropertyChange(Lab3Controller.OUTPUT_MESSAGE, null, s.toString());
        
    }

    public void setRemoveElement(String value) {
 
        StringBuilder s = new StringBuilder();
        
        // INSERT YOUR CODE HERE
        s.append("Page Removed: ").append(buffer.remove(value)).append(System.lineSeparator());

        s.append(buffer);

        firePropertyChange(Lab3Controller.OUTPUT_MESSAGE, null, s.toString());
        
    }

    public void sendOutputMessage(String message) {
        
        firePropertyChange(Lab3Controller.OUTPUT_MESSAGE, null, message);
        
    }
    
}