/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs350;


/**
 *
 * @author mkirby8
 */
public class BoundedBuffer {
    
    private static final int BUFFER_SIZE = 4;
    private int count, in, out;
    protected String[] buffer;
    protected int[] counter;
    protected boolean[] validBits;
    private Lab3Model model;
    
    public BoundedBuffer(Lab3Model model) {
        
        this.model = model;
        count = in = out = 0;
        buffer = new String[BUFFER_SIZE];
        counter = new int[BUFFER_SIZE];
        validBits = new boolean[BUFFER_SIZE];
    }
    
    
    public synchronized void insert(String page) {
    
        for (int i = 0; i < BUFFER_SIZE; i++) {
            if (buffer[i] != null && buffer[i].equals(page)) {
                counter[i] = 0;
                updateCounters();
                return;
            }
        }
        
        if (count == BUFFER_SIZE) {
            int minCounterIndex = 0;
            for (int i = 1; i < BUFFER_SIZE; i++) {
                if (counter[i] > counter[minCounterIndex]) {
                    minCounterIndex = i;
                }
            }
            buffer[minCounterIndex] = page;
            counter[minCounterIndex] = 0;
            validBits[minCounterIndex] = true;
        } else {
            buffer[in] = page;
            counter[in] = 0;
            validBits[in] = true;
            in = (in + 1) % BUFFER_SIZE;
            count++;
        }          
        
        updateCounters();  
        //toString();
    }
    
    public synchronized String remove(String page) {
        
        if (count == 0) 
        {
            return null;
        }
        
        int pageIndex = 0;
        for (int i = 0; i < BUFFER_SIZE; i++) {
            if (page.equals(buffer[i])){
                pageIndex = i;
                break;
            }
        }
        String removedItem = buffer[pageIndex];
        buffer[pageIndex] = null;
        counter[pageIndex] = 0;
        validBits[pageIndex] = false;
        count--;
  
        updateCounters();
        //toString();
        return removedItem;
    }

    
    private void updateCounters() {
        for (int i = 0; i < BUFFER_SIZE; i++) {
            if (buffer[i] != null) {
                counter[i]++;
            }
        }
    }
    
    public String toString() {
        StringBuilder s = new StringBuilder();
        
        s.append("Memory contents: ");
        
        for (int i = 0; i < BUFFER_SIZE; i++) {
            if (buffer[i] != null) {
                s.append(buffer[i]).append(",").append(counter[i]).append(",").append(validBits[i] ? 1 : 0).append(" ");
            } else {
                s.append("_,0,").append(validBits[i] ? 1 : 0).append(" ");
            }
        }
        return s.toString();
    }
    
}
