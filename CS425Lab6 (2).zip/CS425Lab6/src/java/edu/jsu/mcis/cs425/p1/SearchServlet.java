/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1;

import edu.jsu.mcis.cs425.p1.dao.DAOFactory;
import edu.jsu.mcis.cs425.p1.dao.SearchDAO;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import com.github.cliftonlabs.json_simple.*;
import java.util.Map;

/**
 *
 * @author makiy
 */
public class SearchServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {

        DAOFactory daoFactory = null;

        ServletContext context = request.getServletContext();

        if (context.getAttribute("daoFactory") == null) {
            System.err.println("*** Creating New DAOFactory Instance ...");
            daoFactory = new DAOFactory();
            context.setAttribute("daoFactory", daoFactory);
        }
        else {
            daoFactory = (DAOFactory) context.getAttribute("daoFactory");
        }

        response.setContentType("application/json;charset=UTF-8");

        try ( PrintWriter out = response.getWriter()) {

            String scheduleTypeId = request.getParameter("scheduletypeid");
            String courseNumber = request.getParameter("num");
            String subjectId = request.getParameter("subjectid");
            String termId = request.getParameter("termid");
            String levelId = request.getParameter("levelid");
            String startTime = request.getParameter("start");
            String endTime = request.getParameter("end");
            String days = request.getParameter("days");
            
            Map<String, String[]> params = request.getParameterMap();
            

            SearchDAO searchDAO = daoFactory.getSearchDAO();
            
           // System.out.println("DAO Parameters: " + termId + ", " + subjectId + ", " + courseNumber + ", " + levelId + ", " + scheduleTypeId + ", " + startTime + ", " + endTime + ", " + days);
    

            
            JsonArray searchCriteria = searchDAO.search(params, Integer.parseInt(request.getParameter("termid")));

            JsonObject json = new JsonObject();
            json.put("courses", searchCriteria);
            out.println(Jsoner.serialize(json));
            

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        doGet(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Search Servlet";
    }
}

    

