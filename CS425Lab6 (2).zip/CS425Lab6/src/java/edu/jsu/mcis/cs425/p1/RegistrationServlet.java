/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import edu.jsu.mcis.cs425.p1.dao.DAOFactory;
import edu.jsu.mcis.cs425.p1.dao.RegistrationDAO;
import jakarta.servlet.ServletContext;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import com.github.cliftonlabs.json_simple.*;

/**
 *
 * @author makiy
 */
public class RegistrationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        
        DAOFactory daoFactory = null;

        ServletContext context = request.getServletContext();

        if (context.getAttribute("daoFactory") == null) {
            System.err.println("*** Creating New DAOFactory Instance ...");
            daoFactory = new DAOFactory();
            context.setAttribute("daoFactory", daoFactory);
        }
        else {
            daoFactory = (DAOFactory) context.getAttribute("daoFactory");
        }

        response.setContentType("application/json;charset=UTF-8");
        

        String termId = request.getParameter("termid");
        String crn = request.getParameter("crn");

        try ( PrintWriter out = response.getWriter() ) {
            
            RegistrationDAO registrationDAO = daoFactory.getRegistrationDAO();

            String username = "p1user";
            int studentId = registrationDAO.getStudentId(username);
            System.out.println(studentId + " " + termId + " " + crn);
            registrationDAO.registerCourse(studentId, termId, crn);
            
            
            JsonObject jsonResponse = new JsonObject();
            jsonResponse.put("message", "Student registered successfully");
            out.println(Jsoner.serialize(jsonResponse));
            
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        
        DAOFactory daoFactory = null;

        ServletContext context = request.getServletContext();

        if (context.getAttribute("daoFactory") == null) {
            System.err.println("*** Creating New DAOFactory Instance ...");
            daoFactory = new DAOFactory();
            context.setAttribute("daoFactory", daoFactory);
        }
        else {
            daoFactory = (DAOFactory) context.getAttribute("daoFactory");
        }
        response.setContentType("application/json;charset=UTF-8");
    
        String termId = request.getParameter("termid");

        try (PrintWriter out = response.getWriter()) {
            RegistrationDAO registrationDAO = daoFactory.getRegistrationDAO();
            //String username = (String) request.getSession().getAttribute("username");
            String username = "p1user";

            int studentId = registrationDAO.getStudentId(username);
            JsonArray registrations = registrationDAO.listRegistrations(studentId, termId);

            out.println(Jsoner.serialize(registrations));

        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) {
        
        DAOFactory daoFactory = null;

        ServletContext context = request.getServletContext();

        if (context.getAttribute("daoFactory") == null) {
            System.err.println("*** Creating New DAOFactory Instance ...");
            daoFactory = new DAOFactory();
            context.setAttribute("daoFactory", daoFactory);
        }
        else {
            daoFactory = (DAOFactory) context.getAttribute("daoFactory");
        }
        
        response.setContentType("application/json;charset=UTF-8");

        String termId = request.getParameter("termid");
        String crn = request.getParameter("crn");

        try (PrintWriter out = response.getWriter()) {
            
            RegistrationDAO registrationDAO = daoFactory.getRegistrationDAO();
            String username = "p1user";

            int studentId = registrationDAO.getStudentId(username);
            
            registrationDAO.deleteRegistration(studentId, termId, crn);
            
            System.out.println(studentId + " " + termId + " " + crn);
            
            JsonObject jsonResponse = new JsonObject();
            jsonResponse.put("message", "Course deleted/dropped successfully");  
            out.println(Jsoner.serialize(jsonResponse));


        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public String getServletInfo() {
        return "Registration Servlet";
    }
}


