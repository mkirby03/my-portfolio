/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;

/**
 *
 * @author makiy
 */

import java.sql.*;

public class ScheduleTypeDAO {
    
    private static final String QUERY_SCHEDULE = "SELECT * FROM scheduletype";
    
    private final DAOFactory daoFactory;

    public ScheduleTypeDAO(DAOFactory daoFactory) {
        this.daoFactory = daoFactory;
    }    
    
    public String getScheduleTypesAsHTML() {
        
        StringBuilder s = new StringBuilder();
        
        
        try 
        {
            Connection conn = daoFactory.getConnection();
            PreparedStatement ps = conn.prepareStatement(QUERY_SCHEDULE);
            
            ResultSet rs = ps.executeQuery();
            
            s.append("<select id=\"scheduletypeid\" name=\"scheduletypeid\">");

            while (rs.next()) {
                
                String id = rs.getString("id");
                String description = rs.getString("description");
                s.append("<option value=").append(id).append(">");
                s.append(description).append("</option>");
                
            }
            
            s.append("</select>");
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return s.toString();
        
    }
}
