/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;

/**
 *
 * @author makiy
 */

import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DAOFactory {
    
    
    //private static final String PREFIX = "p1";
    //private static final String PROPERTY_ENVCONTEXT = "envcontext";
    //private static final String PROPERTY_INITCONTEXT = "initcontext";
    
    private Connection conn;
    
    public DAOFactory() {

        //DAOProperties properties = new DAOProperties(PREFIX);

        //String envcontext = properties.getProperty(PROPERTY_ENVCONTEXT);
        //String initcontext = properties.getProperty(PROPERTY_INITCONTEXT);
        
        try {
            Context envContext = new InitialContext();
            Context initContext = (Context) envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource) initContext.lookup("jdbc/db_pool");
            if (ds != null) {
                this.conn = ds.getConnection();
            }
        }
        catch (Exception e) {
            conn = null;
            e.printStackTrace();
        }
        
    }
    
    Connection getConnection() {
        return conn;
    }
    
    public boolean isClosed() {
        
        boolean isClosed = true;
        
        try {
            isClosed = conn.isClosed();
        }
        catch (Exception e) { e.printStackTrace(); }
        
        return isClosed;
        
    }
    
    public SearchDAO getSearchDAO() {
        return new SearchDAO(this);
    }

    public RegistrationDAO getRegistrationDAO() {
        return new RegistrationDAO(this);
    }
    
    public TermDAO getTermDAO() {
        return new TermDAO(this);
    }
    
    public SubjectDAO getSubjectDAO() {
        return new SubjectDAO(this);
    }
    
    public ScheduleTypeDAO getScheduleTypeDAO() {
        return new ScheduleTypeDAO(this);
    }
    
    public CourseLevelDAO getCourseLevelDAO() {
        return new CourseLevelDAO(this);
    }
}
