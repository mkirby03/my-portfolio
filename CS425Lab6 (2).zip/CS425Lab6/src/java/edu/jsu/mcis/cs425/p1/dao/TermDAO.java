/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;


/**
 *
 * @author makiy
 */

import java.sql.*;

public class TermDAO {
    
    private static final String QUERY_TERM = "SELECT * FROM term";
    
    private final DAOFactory daoFactory;

    public TermDAO(DAOFactory daoFactory) {
        this.daoFactory = daoFactory;
    }

    public String getTermsAsHTML() {
        
        StringBuilder s = new StringBuilder();
        
        
        try 
        {
            Connection conn = daoFactory.getConnection();
            PreparedStatement ps = conn.prepareStatement(QUERY_TERM);
            
            ResultSet rs = ps.executeQuery();
            
            s.append("<select id=\"termid\" name=\"termid\">");

            while (rs.next()) {
                
                String id = rs.getString("id");
                String name = rs.getString("name");
                s.append("<option value=").append(id).append(">");
                s.append(name).append("</option>");
                
            }
            
            s.append("</select>");
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return s.toString();
        
    }
    
}
