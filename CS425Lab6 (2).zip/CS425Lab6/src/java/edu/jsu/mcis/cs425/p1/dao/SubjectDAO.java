/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;


/**
 *
 * @author makiy
 */

import java.sql.*;

public class SubjectDAO {
    
    private static final String QUERY_SUBJECT = "SELECT * FROM subject";
    
    private final DAOFactory daoFactory;

    public SubjectDAO(DAOFactory daoFactory) {
        this.daoFactory = daoFactory;
    }

    public String getSubjectsAsHTML() {
        
        StringBuilder s = new StringBuilder();
        
        
        try 
        {
            Connection conn = daoFactory.getConnection();
            PreparedStatement ps = conn.prepareStatement(QUERY_SUBJECT);
            
            ResultSet rs = ps.executeQuery();
            
            s.append("<select id=\"subjectid\" name=\"subjectid\">");

            while (rs.next()) {
                
                String id = rs.getString("id");
                String name = rs.getString("name");
                s.append("<option value=").append(id).append(">");
                s.append(name).append("</option>");
                
            }
            
            s.append("</select>");
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return s.toString();
        
    }
}
