/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1;

import java.util.HashMap;

/**
 *
 * @author makiy
 */
public class SearchCriteriaBean {
    
    private HashMap<String, String> parameters = null;
    
    public SearchCriteriaBean() {
        parameters = new HashMap<>();
    }
    
    public void clear() {
        parameters.clear();
    }
    
    public int getSessionid() {
        return Integer.parseInt(parameters.get("sessionid"));
    }

    public void setSessionid(int sessionid) {
        parameters.put("sessionid", String.valueOf(sessionid));
    }

    public String getTermId() {
        return parameters.get("termid");
    }

    public void setTermId(String termId) {
        parameters.put("termid", termId);
    }

    public String getSubjectId() {
        return parameters.get("subjectid");
    }

    public void setSubjectId(String subjectId) {
        parameters.put("subjectid", subjectId);
    }

    public String getCourseNumber() {
        return parameters.get("num");
    }

    public void setCourseNumber(String num) {
        parameters.put("num", num);
    }
    
    public String getLevelId() {
        return parameters.get("levelid");
    }

    public void setLevelId(String levelid) {
        parameters.put("levelid", levelid);
    }
    
    public String getScheduleTypeId() {
        return parameters.get("scheduletypeid");
    }

    public void setScheduleTypeId(String scheduletypeid) {
        parameters.put("scheduletypeid", scheduletypeid);
    }
    
    public String getStartTime() {
        return parameters.get("start");
    }

    public void setStartTime(String start) {
        parameters.put("start", start);
    }
    
    public String getEndTime() {
        return parameters.get("end");
    }

    public void setEndTime(String end) {
        parameters.put("end", end);
    }
    
    public String getDays() {
        return parameters.get("days");
    }

    public void setDays(String days) {
        parameters.put("days", days);
    }
    
    public String getCrn() {
        return parameters.get("crn");
    }

    public void setCrn(String crn) {
        parameters.put("crn", crn);
    }

}
