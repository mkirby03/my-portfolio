/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.jsu.mcis.cs425.p1.dao;

/**
 *
 * @author makiy
 */

import com.github.cliftonlabs.json_simple.*;

public class DAOUtility {
    
    public static String JsonToHtml(JsonArray courses) {
        
        StringBuilder html = new StringBuilder();
        
        for (Object obj : courses) {
            
            JsonObject course = (JsonObject) obj;
            
            html.append("<table style='margin-bottom: 10px; width: 100%; border-collapse: collapse;'>");
            html.append("<tr>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>CRN</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Subject ID</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Course Number</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Section</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Term</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Level</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Credits</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Days</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Where</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Start Date</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>End Date</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Schedule Type</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Instructor(s)</th>")
                .append("</tr>")
                .append("<tr>")
                .append("<td style='padding: 5px;'>").append(course.get("crn")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("subjectid")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("num")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("section")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("name")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("description")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("credits")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("days")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("where")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("start")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("end")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("scheduletypeid")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("instructor")).append("</td>")
                .append("</tr>")
                .append("</table><br>");
            
        }
        
        return html.toString();
    }
    
    public static String ScheduleToHtml(JsonArray courses) {
        
        StringBuilder html = new StringBuilder();
        
        for (Object obj : courses) {
            
            JsonObject course = (JsonObject) obj;
            
            html.append("<table style='margin-bottom: 10px; width: 100%; border-collapse: collapse;'>");
            html.append("<tr>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Name</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>CRN</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Subject ID</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Course Number</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Section</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Start Time</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>End Time</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Days</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Where</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Schedule Type</th>")
                .append("<th style='padding: 5px; text-align: left; background-color: #f0f0f0;'>Instructor(s)</th>")
                .append("</tr>")
                .append("<tr>")
                .append("<td style='padding: 5px;'>").append(course.get("name")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("crn")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("subjectid")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("num")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("section")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("start")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("end")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("days")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("where")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("scheduletypeid")).append("</td>")
                .append("<td style='padding: 5px;'>").append(course.get("instructor")).append("</td>")
                .append("</tr>")
                .append("</table><br>");
            
        }
        
        return html.toString();
    }
    
    
    
}
