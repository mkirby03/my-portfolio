
var init = function() {
    
    $("#message").html( $().jquery );
    
};

var submitRegistration = function() {

    $.ajax({
        url: "../registration",
        method: "POST",
        data: $("#inputform").serialize(),
        dataType: "json",
        success: function(response) {
            console.log(response);
            $("#message").html(response.message);
        }
    });
    
    return false;
    
};

var submitDrop = function() {
    
    var termid = $('#termid').val();
    var crn = $('#crn').val();

    var url = `../registration?termid=${encodeURIComponent(termid)}&crn=${encodeURIComponent(crn)}`;
    
    $.ajax({
        url: url,
        method: "DELETE",
        dataType: "json",
        success: function(response) {
            console.log(response);
            $("#message").html(response.message);
        },
        error: function(xhr) {
            console.log("Error: " + xhr.responseText);
            $("#message").html(xhr.responseText);
        }
    });
    
    return false;
    
};